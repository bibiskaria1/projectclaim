export class Plans {
    PId;
    Pname;
    Amount;
    Start;
    End;
    MrefID;
}
