import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navnew',
  templateUrl: './navnew.component.html',
  styleUrls: ['./navnew.component.css']
})
export class NavnewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
