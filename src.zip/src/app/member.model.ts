export class Member {
    Mid;
    MName;
    Username;
    Password;
    Address;
    State;
    Country;
    Email;
    Contact;
    DOJ;
}
