export class Plan {
    PId;
    Pname;
    Amount;
    Start;
    End;
}
